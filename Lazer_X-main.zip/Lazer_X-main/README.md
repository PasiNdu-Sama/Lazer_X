<div align="center">
  <img src="https://telegra.ph/file/f39250b4f94fd7be7a0b7.png" width="300" height="300">
  <h1>Sup! This is Lazer_X </h1>
</div>

<p align="center">
    This is Lazer_X. An cool whatsapp bot with amazing features. This will help you with many tasks.
</p>

----

  </a>
</p>

### How to setup Lazer_X

### To scan The Qr code of Lazer_X, click the button below.
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@Pasindu-Samarakoon/LazerX?v=1)

`Then play the video and generate the Qr code from another device`
`Now take the device that you want to make Lazer_X and scan the Qr code from Whatsapp Web`

### To Deploy your Lazer_X to heroku, click the button below.
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/PasiNdu-SamaraKooN/Lazer_X.git)

----

<p align="center">
  <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X">
    <img src="https://img.shields.io/badge/Docker%20Pulls-pasindu--samarakoon%2FlazerX-aqua">
  </a>
 
 <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X">
    <img src="https://img.shields.io/badge/Image%20Size-728%20MB-blue">
    </a>
</p>

<p align="center">
  <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FPasiNdu-SamaraKooN%2FLazer_X&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  </a>
  <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X/fork">
    <img src="https://img.shields.io/github/forks/PasiNdu-SamaraKooN/Lazer_X?label=Fork&style=social">
    </a>
  <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X/stargazers">
    <img src="https://img.shields.io/github/stars/PasiNdu-SamaraKooN/Lazer_X?style=social">
  </a>
</p>

<p align="center">
  <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X">
    <img src="https://img.shields.io/github/repo-size/PasiNdu-SamaraKooN/Lazer_X?color=green&red=Repo%20Size&style=plastic">
   </a>
  <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X">
    <img src="https://img.shields.io/github/license/PasiNdu-SamaraKooN/Lazer_X?color=green&red=License&style=plastic">
   </a>
   <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X">
    <img src="https://img.shields.io/badge/Languages%20-JavaScript%2098.4%25-green&red">
   </a>
  <a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X">
    <img src="https://img.shields.io/static/v1?label=Author&message=PasiNdu%20SamaraKooN&color=purple&style=plastic">
   </a>
  </p>

<p align="center">
  <a href="https://wa.me/94719603031">
    <img src="https://img.shields.io/badge/Contact%20Me%20On%20Whatsapp-PasiNdu%20SamaraKooN-purple&style=plastic">
  </a>
</p>

----

### Here is the Lazer_X Comand List.

<a href="https://gist.github.com/PasiNdu-SamaraKooN/e454d94d6dbe080e933b9db7324bdb0e">
    <img src="https://img.shields.io/badge/Lazer%20X-purple&style=plastic">

----

### ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned. Lazer_X is an open source project, you are responsible for everything you do. Absolutely, Lazer_X executives do not accept responsibility. By establishing the Lazer_X, you are deemed to have accepted these responsibilities.
```

----

### Team Lazer_X

### 💻Owner, Developer & Management.

<a href="https://github.com/PasiNdu-SamaraKooN/Lazer_X.git">
    <img src="https://telegra.ph/file/81c3b795d770f63079ff6.png" width="200" height="200">
  </a>

(Pasindu_Samarakoon)

<a href="https://wa.me/+94719603031">
    <img src="https://img.shields.io/badge/Contact%20me%20on%20WhatsApp-purple&style=plastic">
   </a>
  
### 💻Co-Host, Developer & Management.

<a href="http://wa.me/94772842356">
    <img src="https://telegra.ph/file/a57f5d4d523d374c861f9.jpg" width="200" height="200">
  </a>

(Uchiha_Itachi)

<a href="http://wa.me/94772842356">
    <img src="https://img.shields.io/badge/Contact%20me%20on%20WhatsApp-purple&style=plastic">
   </a>
  
### 💻Idea & Management.

<a href="https://wa.me/94718846368">
    <img src="https://telegra.ph/file/666b405ec87168c327b1f.jpg" width="200" height="200">
  </a>

(Vishwa_Hansa)

<a href="https://wa.me/94718846368">
    <img src="https://img.shields.io/badge/Contact%20me%20on%20WhatsApp-purple&style=plastic">
   </a>

----

### 📱Have Fun And Make your whatsApp more Useful with Lazer_X!    
